Formation ORION - Step 17  
========================  
   
  
Complément à l'étape 16
----------------------  

Ajout des Rapports/Editions sur la liste des agriculteurs.    
Exercice 1 : Edition au formats bruts (csv)
Exercice 2 : Edition au formats bruts (txt, xml)
Exercice 3 : Edition au formats bruts (xml : exclusion de propriétés)
Exercice 4 : Edition au formats bureautiques avec ORS (xml : exclusion de propriétés)
Exercice 5 : Edition avec la webapp de tests
Exercice 6 : Editions : Preferences d'éditions
  
Complément à l'étape 15
----------------------  

Ajout des habilitations.    
Exercice 3 : Filtrage sur les actions.    
L'action de modification de l'agriculteur est bloquée.       
  
  
  
Complément à l'étape 14
----------------------  

Ajout des habilitations.    
Exercice 2 (optionnel) : Filtrage partiel du Business Agriculteur.    
Seul le nom et le prénom de l'agriculteur peuvent être lu. Les autres données sont masquées.  
Attention : les droits en lecture ne sont pas appliqués sur les listes !    
  
  
  
Complément à l'étape 13  
----------------------  

Ajout des habilitations.    
Exercice 1 : Application en RO.  
Seul le Business est habilité. L'action de modification est donc autorisée, mais serait rejetée s'il y avait des 
modifications.  
  
  
  
  
Complément à l'étape 12  
----------------------  

Ajout de rules métier et leurs Tests Unitaires.    
  
  
  
  
Complément à l'étape 11  
----------------------  

Ajout d'une directive AJAX sur la modification du statut de l'agriculteur.      


  

Complément à l'étape 10  
----------------------  

Ajout d'un guide pour choisir le type d'agriculteur sur le wizard de modification.         

  

Complément à l'étape 9  
----------------------  

Ajout d'une slavelist de parcelles sur le wizard de modification de l'agriculteur avec possibilité d'ajouter des parcelles.         

  

Complément à l'étape 8  
----------------------  

Transforme la modification d'un agriculteur en formulaire à assistant.       

  

Complément à l'étape 7  
----------------------  

Transforme la visualisation d'un agriculteur en formulaire à onglets.     

  

Complément à l'étape 6  
----------------------  

Ajoute les préférences de recherches.   

  

Complément à l'étape 5  
----------------------  

Ajoute une section de recherche en en-tête de liste.  
Inclus un auto-complete dans la recherche.            

  

Complément à l'étape 4  
----------------------  

Ajoute une nouvelle colonne dans la liste des agrculteurs.  
Ajoute un expand dans cette colonne.  
Affiche du Lorem Ipsum dans la table après expansion.        

  

Complément à l'étape 3  
----------------------  

Ajoute une colonne d'action à la liste d'agriculteurs.  
2 actions dans la dropDown, qui envoie vers un formulaire d'édition de l'agriculteur, en lecture seule ou modification selon l'entrée.  
  
  

Complément à l'étape 2  
----------------------  

Ajoute une liste d'agriculteurs accessibles via la menu horizontal.  
  
  

Complément à l'étape 1  
----------------------  

Définit un titre et une page d'accueil.  
Définit une première entrée dans le menu horizontal.   
