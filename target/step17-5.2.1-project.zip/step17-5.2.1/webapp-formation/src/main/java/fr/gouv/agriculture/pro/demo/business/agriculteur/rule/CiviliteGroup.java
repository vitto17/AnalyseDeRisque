package fr.gouv.agriculture.pro.demo.business.agriculteur.rule;

import javax.validation.groups.Default;

/**
 * Groupe de validation de la civilite des agriculteurs.
 * 
 * @author olivier.dupre
 * @version $Id : $
 */
public interface CiviliteGroup extends Default {
}